package com.microservice.credit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroserviceCreditApplicationTests {

	@Test
	void contextLoads() {
	}

}
